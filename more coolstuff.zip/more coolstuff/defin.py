import numpy as np
# G(x) and m(x) exponets

solver=[""]*3
solver[0]=complex(0,1)
solver[1]=complex(0,2)
solver[2]=complex(0,3)

# G(x) consents 
solfront=[""]*3
solfront[0]=complex(1,0)
solfront[1]=complex(2,0)
solfront[2]=complex(4,0)


# F(x) consents 
quesfront=[""]*3

quesfront[0]=complex(1,0)
quesfront[1]=complex(3,0)
quesfront[2]=complex(4,0)


# solotion consents
sol=[""]*3
sol[0]=complex(0,1)
sol[1]=complex(0,2)
sol[2]=complex(0,3)
inigrand=[complex(0,0),complex(0,1)]

def invcomplex(v):
	ID=[""]*len(v)
	for x in range(len(v)):
		ID[x]=np.zeros(len(v))
	for x in range(len(v)):
		ID[x][x]=1
	vnID=[""]*len(v)
	for x in range(len(v)):
		vnID[x]=np.hstack((v[x],ID[x]))
	#prinver_F(vnID)

	leen=len(v)
	# row reducse
	for y in range(len(v)):
		for x in range(len(v)-y):
			vnID[x+y]=vnID[x+y]/vnID[x+y][y]
		for z in range(len(v)-(y+1)):
			vnID[z+(y+1)]=vnID[z+(y+1)]-vnID[y]
	#print(vnID[1]*vnID[0][0])
	for y in range(len(v)-1):
		for k in range(len(v)-(y+1)):
			this=vnID[k+1+y]*vnID[y][k+1+y]
			vnID[y]=vnID[y]-this


	invs=[""]*len(v)
	for x in range(len(v)):
		invs[x]=[""]*len(v)
	for x in range(len(v)):
		for y in range(len(v)):
			invs[y][x]=vnID[y][x+len(v)]
	return invs


def makematrix_fordeffuncsolve_F(solver,sol,inigrand):
	matrix=[""]*len(sol)
	for x in range(len(sol)):
		matrix[x]=np.zeros(len(sol),dtype=np.complex_)
		for y in range(len(sol)):
			that=2.71828182846**((solver[x]+sol[y])*inigrand[1])
			thow=2.71828182846**((solver[x]+sol[y])*inigrand[0])
			matrix[x][y]=(thow-that)/(solver[x]+sol[y])
	return matrix
thay=makematrix_fordeffuncsolve_F(solver,sol,inigrand)
here=invcomplex(thay)
#print(here)

solfront=[""]*3
solfront[0]=complex(1,0)
solfront[1]=complex(2,0)
solfront[2]=complex(4,0)

quesfront=[""]*3

quesfront[0]=complex(1,0)
quesfront[1]=complex(3,0)
quesfront[2]=complex(4,0)
def makevecformatrix_fordeffsolv_F(ques,sol):
	vec=np.zeros(len(sol),dtype=np.complex_)
	for x in range(len(sol)):
		vec[x]=sol[x]/ques[x]
	return vec
vector=makevecformatrix_fordeffsolv_F(quesfront,solfront)

done=np.dot(here,vector)
print(vector)
print(here[2])
print(done)

def solpair_F(front,exp):
	res=[""]*len(front)
	for x in range(len(front)):
		res[x]=[done[x],"exp",exp[x]]
	return res
gotit=solpair_F(done,sol)
print(gotit)
	




