import numpy as np
import matplotlib.pyplot as plt
import math
from numpy import arange
import pylab
vector1=[1,2,-1,2,4,1,2,4,2,4,1,-2,1,3,-2,10]
start_time=-math.pi
endds_time=math.pi
number=18
def foir_step_exp_F(vector1,start_time,endds_time,number):
	vec1=[""]*(len(vector1)*2+1)
	vec1[0]=vector1[0]
	for x in range(len(vector1)-1):
		vec1[2*x+1]=vector1[x+1]
		vec1[2*x+2]=vector1[x+1]
	vecs1=[""]*(len(vector1)*2)
	for x in range(len(vector1)):
		vecs1[2*x+0]=vector1[x]
		vecs1[2*x+1]=vector1[x]
	time1=[""]*len(vecs1)
	time1[0]=start_time
	for x in range(len(time1)//2-1):
		time1[2*x+0+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
		time1[2*x+1+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
	time1[len(time1)-1]=endds_time
	def de_in_sin_F(a,top,bot):
		return (math.cos(a*bot)-math.cos(a*top))/a
	def de_in_cos_F(a,top,bot):
		return (math.sin(a*top)-math.sin(a*bot))/a
	S=[0]*number
	C=[0]*number
	for x in range(number):
		a=2*math.pi*(x+1)/(endds_time-start_time)
		for y in range(len(time1)//2):
			
			mult=de_in_sin_F(a,time1[2*y],time1[2*y+1])
			add=vector1[y]*mult
			S[x]=S[x]+add
			mult2=de_in_cos_F(a,time1[2*y],time1[2*y+1])
			add2=vector1[y]*mult2
			C[x]=C[x]-add2
		S[x]=2*S[x]/(start_time-endds_time)
		C[x]=2*C[x]/(endds_time-start_time)
	ret=[0]*(2*number+1)
	A0=(sum(vector1))/(len(vector1))
	ret[0]=[A0,"Con",1]
	for x in range(number):
		ret[2*x+1+0]=[complex(1/2*C[x],1/2*S[x]),"exp",complex(0,-2*math.pi*(x+1)/(endds_time-start_time))]
		ret[2*x+1+1]=[complex(1/2*C[x],-1/2*S[x]),"exp",complex(0, 2*math.pi*(x+1)/(endds_time-start_time))]
	return ret

this=foir_step_exp_F(vector1,start_time,endds_time,number)
print(this)

def plot_m(funct,start_time,endds_time):
	test=0
	k = np.linspace(start_time,endds_time,1000)
	for x in range(len(funct)):
		if funct[x][1]=="con":
			test=test+np.real(funct[0])
		if funct[x][1]=="exp":
			test=test+funct[x][0]*2.71828182846**(funct[x][2]*k)
	test=test+k
	pylab.plot(k,test)
	plt.show()

def invcomplex(v):
	ID=[""]*len(v)
	for x in range(len(v)):
		ID[x]=np.zeros(len(v))
	for x in range(len(v)):
		ID[x][x]=1
	vnID=[""]*len(v)
	for x in range(len(v)):
		vnID[x]=np.hstack((v[x],ID[x]))
	#prinver_F(vnID)

	leen=len(v)
	# row reducse
	for y in range(len(v)):
		for x in range(len(v)-y):
			vnID[x+y]=vnID[x+y]/vnID[x+y][y]
		for z in range(len(v)-(y+1)):
			vnID[z+(y+1)]=vnID[z+(y+1)]-vnID[y]
	#print(vnID[1]*vnID[0][0])
	for y in range(len(v)-1):
		for k in range(len(v)-(y+1)):
			this=vnID[k+1+y]*vnID[y][k+1+y]
			vnID[y]=vnID[y]-this


	invs=[""]*len(v)
	for x in range(len(v)):
		invs[x]=[""]*len(v)
	for x in range(len(v)):
		for y in range(len(v)):
			invs[y][x]=vnID[y][x+len(v)]
	return invs

plot_m(this,start_time,endds_time)



	




