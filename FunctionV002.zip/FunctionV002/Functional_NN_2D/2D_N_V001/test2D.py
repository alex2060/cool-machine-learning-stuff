import newfist_try_F1 as nets
import numpy as np
import random
import copy
import newpoly1number2 as poly
import math
import matplotlib.pyplot as plt


def flip_vec(vec):
	newvec=[0]*len(vec)
	for x in range(len(vec)):
		newvec[len(vec)-x-1]=vec[x]
	return newvec

data2D= [
		[0,0,0],
		[0,5,0],
		[0,0,0]
		]
newonw=np.arange(len(data))


for x in range(len(data)):
	newonw[x]=data[x]

flipvec=flip_vec(data)





def make_2DcosfunctionP1(data,numberx,numbery,start,stop):
	makeit=[0]*len(data)
	for x in range(len(data)):
		makeit[x]=poly.return_Function_C_S(data[x],start,stop,numberx)
	
	return makeit


def make_2Dcosfunction(data,numberx,numbery,start,stop):
	makeit=[0]*len(data)
	for x in range(len(data)):
		makeit[x]=poly.return_Function_C_S(data[x],start,stop,numberx)
		#print(makeit[x])
	doit=[0]*(numberx*2+1)

	print("next")
	for x in range(len(doit)):
		doit[x]=[0]*len(data)
		for y in range(len(data)):
			doit[x][y]=makeit[y][x]
	out=[0]*len(doit)
	for x in range(len(doit)):
		#plt.plot(doit[x])
		#plt.show()
		out[x]=poly.return_Function_C_S(doit[x],start,stop,numbery)
		#poly.plotfunction(out[x],1000)
	return out

there=make_2Dcosfunction(data2D,4,4,0,1)

#print(out1[1])
#print(out1[2])
print("here we go")
def plot_fun2D(data,val):
	pol=[0]*1000
	for x in range(1000):
		pol[x]=out_2Dfunction(data,val,x/1000)
	plt.plot(pol)
	plt.show()

def out_2Dfunction(Funch,x,y):
	myfun1=[0]*len(Funch)
	for k in range(len(Funch)):
		myfun1[k]=poly.outfunc(Funch[k],x)
	return poly.outfunc(myfun1,y)

print("go we go now")

there=make_2Dcosfunction(data2D,10,10,0,1)
plot_fun2D(there,0)
plot_fun2D(there,0.5)
#poly.plotfunction(there[0],1000)
#plt.plot(data2D[0])
#plt.show()







