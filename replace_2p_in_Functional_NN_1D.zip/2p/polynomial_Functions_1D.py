import numpy as np
import copy
from numpy.linalg import inv
import matplotlib.pyplot as plt
import math
import matplotlib.pyplot as plt
def plot_valofseries(vals):
	k = np.linspace(0,1,1000)
	p=[0]*100
	for x in range((len(vals))//2):
		p=p+vals[x]*np.sin(2*math.pi*(x+1)*k/(endds_time-start_time))+vals[2][x]*np.cos(2*math.pi*(x+1)*k/(endds_time-start_time))
	pylab.plot(k,p)
	plt.show()

def plotfunction(fun1,number):
	out=[0]*number
	for x in range( number ):
		out[x]=outfunc(fun1, (x/(number-1)))
	k = np.linspace(0,1,1000)
	plt.plot(k,out)
	plt.show()

def returnval(vals,k):
	p=0
	#maybe p=vals[0]
	for x in range( (len(vals)-1)//2 ):
		p=p-vals[2*x+1]*np.sin(2*math.pi*(x+1)*k/(1))+vals[2*x+2]*np.cos(2*math.pi*(x+1)*k/(1))
	return p

def split(vec):
	out=[0]*(2*len(vec)-1)
	for x in range(len(vec)-1):
		out[2*x]=vec[x]
		out[2*x+1]=(vec[x]+vec[x+1])/2
	out[len(out)-1]=vec[len(vec)-1]
	return out

def reordervals_to_line(vals):
	out=[0]*(2*len(vals[1])+1)
	out[0]=vals[0]
	for x in range(len(vals[1]) ):
		out[1+2*x+0]=vals[1][x]
		out[1+2*x+1]=vals[2][x]
	return out

def line_back(vals):
	out=[0,[0]*( (len(vals)-1)//2 ),[0]*( (len(vals)-1)//2 )]
	out[0]=vals[0]
	for x in range( ( (len(vals)-1)//2 )):
		out[1][x]=vals[1+2*x+0]
		out[2][x]=vals[1+2*x+1]
	return out

def return_Function_C_S(vectormew,start_time,endds_time,number):
	vector1=copy.deepcopy(vectormew)
	vector1=split(split(vector1))
	vec1=[""]*(len(vector1)*2+1)
	vec1[0]=vector1[0]
	for x in range(len(vector1)-1):
		vec1[2*x+1]=vector1[x+1]
		vec1[2*x+2]=vector1[x+1]

	vecs1=[""]*(len(vector1)*2)
	for x in range(len(vector1)):
		vecs1[2*x+0]=vector1[x]
		vecs1[2*x+1]=vector1[x]

	time1=[""]*len(vecs1)
	time1[0]=start_time
	for x in range(len(time1)//2-1):
		time1[2*x+0+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
		time1[2*x+1+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))

	time1[len(time1)-1]=endds_time
	def de_in_sin_F(a,top,bot):
		return (math.cos(a*bot)-math.cos(a*top))/a
	def de_in_cos_F(a,top,bot):
		return (math.sin(a*top)-math.sin(a*bot))/a
	S=[0]*number
	C=[0]*number
	for x in range(number):
		a=2*math.pi*(x+1)/(endds_time-start_time)
		for y in range(len(time1)//2):
			
			mult=de_in_sin_F(a,time1[2*y],time1[2*y+1])
			add=vector1[y]*mult
			S[x]=S[x]+add
			mult2=de_in_cos_F(a,time1[2*y],time1[2*y+1])
			add2=vector1[y]*mult2
			C[x]=C[x]-add2
		S[x]=2*S[x]/(start_time-endds_time)
		C[x]=2*C[x]/(endds_time-start_time)
	A0=0
	A0=(sum(vector1))/(len(vector1))



	return reordervals_to_line([A0,S,C])

def split(vec):
	out=[0]*(2*len(vec)-1)
	for x in range(len(vec)-1):
		out[2*x]=vec[x]
		out[2*x+1]=(vec[x]+vec[x+1])/2
	out[len(out)-1]=vec[len(vec)-1]
	return out

def outfunc(data,number):

	return returnval(data,number)

def shift_function(function,number,rank,amount):
	place=[0]*number
	for x in range(number):
		place[x]=outfunc(function, (amount+x/(number-1)) )

	return return_Function_C_S(place,0,1,rank)

def data_to_function_with_inv_matrix(data,rank,inmatrix):
	return  return_Function_C_S(data,0,1,rank)

def differance(fun1,fun2,rank,dic):
	if rank==1:
		return 1;
	sutm=0
	for x in range( rank ):
		one=outfunc(fun2, (x/(rank-1)))
		two=outfunc(fun1, (x/(rank-1)))
		sutm+=abs( one-two )
	return  sutm

def data_to_function(data,rank):
	# where the fast hankle solver goes 
	if rank==1:
		return [sum(data)/len(data)]
	matrix=np.zeros((rank, rank))
	vec=np.zeros(rank)
	for z in range(len(data)):
		for x in range(rank):
			for y in range(rank):
				matrix[x][y]+=addermaker(x+y,( z/(len(data)-1) ))
	for z in range( len(data) ):
		for x in range( rank ):
			vec[x]+=data[z]*addermaker(x,( z/(len(data)-1) ))
	inmatrix=inv(matrix)
	out=np.dot(inmatrix,vec)
	return out

def sub_func_map(func1,func2,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(len(out)):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) -  outfunc(func2, (x/(rank-1)) ) 
	key="rank"+str(rank)+"_values"+str(len(out))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=1
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)

def mult_func_map(func1,func2,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) *  outfunc(func2, (x/(rank-1)) ) 
	key="rank"+str(rank)+"_values"+str(len(out))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=1
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)

def add_func_map(func1,func2,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(len(out)):
		out[x]= outfunc(func1, (x/(rank-1)) ) +  outfunc(func2, (x/(rank-1)) ) 
	key="rank"+str(rank)+"_values"+str(len(out))
	if key in dic:
		inmatrix=dic[key]
	else:
		inmatrix=make_matrix_inv(rank,len(out))
		dic[key] = inmatrix
	return data_to_function_with_inv_matrix(out,rank,inmatrix)

def sig(x):# sigmod function
	return 1/(1+np.exp(-x))

def sig_func_map(func1,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(len(out)):
		# where fast manipule multiplaication goes
		out[x]= sig( outfunc(func1, (x/(rank-1)) ) )

	key="rank"+str(rank)+"_values"+str(len(out))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=make_matrix_inv(rank,len(out))
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)