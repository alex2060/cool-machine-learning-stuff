
import copy
import random
import 2D_polynomial_Functions as poly
import numpy as np
import os
def returnval(vals,k):
	p=vals[0]
	for x in range((len(vals)-1)//2):
		p=p+vals[2*x+1]*np.sin(2*math.pi*(x+2)*k/(endds_time-start_time))+vals[2*x+2]*np.cos(2*math.pi*(x+1)*k/(endds_time-start_time))
	return p

mfd =	{}

def sig(x):# sigmod function 
	return 1/(1+np.exp(-x))

def sig_vec(x,rank,dic):
	out=[0]*len(x)
	for y in range(len(x)):
		out[y]=poly.sig_func_map(x[y],rank,dic)
	return out


def divsig(x):
	return x*(x-1)

def make_random_net_with_bies(net_type,rows):#makes a random net with bies 
	net=[]
	for x in range(len(net_type)-1):
		net.append(rand_m_n(net_type[x+1],net_type[x]+1,rows[x]) )
	return net
# net_type [nerons layer 1, nerons layer 2, nerons layer3]

def rand_m_n(m,n,rank):#makes randome matrix mXn
	mat=[""]*m
	for x in range(m):
		mat[x]=random_mat(n,rank)
	return mat

def random_mat(x,rank):# makes a random value
	out=[0]*x
	for y in range(x):
		out[y]=[0]*rank
		for z in range(rank):
			out[y][z]=random.random()

	#convert to numpy array 


	return out

def store_net(loc,net):
	numb=0
	for x in range(len(net)):
		name=loc+"L"+str(x)
		print(os.path.isdir(name) )
		if os.path.isdir(name):
			pass
		else:
			os.makedirs(name)
		for y in range(len(net[x]) ):
			theplace=name+"/con"+str(y)+".txt"
			print(theplace)
			f = open(theplace, "w")
			for k in range( len(net[x][y]) ):
				for z in range( len(net[x][y][k]) ):
					f.write(str(net[x][y][k][z]))
					if z!=(len(net[x][y][k])-1):
						f.write(",")
				f.write("\n")
			f.close()



def get_net(loc,net_type):
	thenet=[0]*(len(net_type)-1)
	for x in range( len(net_type)-1):
		thenet[x]=[0]*net_type[x+1]
		for y in range(net_type[x+1]):
			place=loc+"L"+str(x)+"/con"+str(y)
			thenet[x][y]=get_matrix_numbs(place,"")

	return thenet


def get_matrix_numbs(loc,name):
	with open(loc+name+".txt","r") as f:
		array=[""]
		for line in f:
			m=line
			m=m.strip("\n")
			m=m.split(",")
			for x in range(len(m)):
				m[x]=float(m[x])
			array.append(m)
	f.close()
	array.pop(0)
	return array





def numpy_net(net,net_type):
	newnet=[""]*len(net_type)
	for x in range(len(net_type)-1):
		hoy=zeros_f_F(net_type[x+1],net_type[x]+1)
		#print(hoy)
		for y in range(len(hoy[0])):
			for z in range(len(hoy)):

				hoy[z][y]=net[x][z][y]
		net[x]=hoy
	return net



def for_ward_prop2(net,imp,net_type, dic,rank):
	#print(net[0][0][0][0])
	net=numpy_net(net,net_type)
	nerons=[0]*len(net_type)
	for x in range(len(net_type)):
		nerons[x]=zeros_F(net_type[x]+1)
		nerons[x][net_type[x]]=[1]
	#print(nerons[0])
	for x in range(len(imp)):
		nerons[0][x]=imp[x]


	#print("net")
	#print(net[1])
	#print("")
	for x in range(len(net_type)-1):
		#print("nereos")
		#print(nerons[x] )
		hold=mydot(net[x],nerons[x] , rank[x], dic)


		#print(hold)
		#print()
		#print()
		#print("done")

		for k in range(len(nerons[x+1])-1):

			nerons[x+1][k]=hold[k]

	return nerons



def back_ward_prop(net,output,net_type,nerds,lear_rate, dic,rows):
	#print("go")
	pet=numpy_net(net,net_type)

	nerons=[0]*len(net_type)
	
	for x in range(len(net_type)):
		nerons[x]=zeros_F(net_type[x]+1)
		nerons[x][net_type[x]]=[1]
	

	for x in range(len(output)):
		nerons[ len(nerons)-1 ][x]=output[x]

	for tot in range(len(net_type)-1):
		val1=sig_vec( nerons[ len(nerons)-1-tot] , rows[len(net)-1-tot] ,dic )
		val2=sig_vec(nerds[len(nerons)-1-tot] , rows[len(net)-1-tot] , dic)
		delta=subtractvec(val1 ,val2 , rows[len(net)-1-tot] , dic)
		delta.pop(len(delta)-1)

		holder=sig_vec(nerds[len(nerons)-2-tot] , rows[len(net)-1-tot] , dic)

		
		nethold=copy.deepcopy(pet[len(net)-1-tot])

		for x in range(len(nethold)):
			#print("we are")
			#print(delta[tot][x])
			#print(nethold[x])
			#print("here")
			nethold[x]=vector_mult_by_consent(nethold[x], delta[x] , rows[len(net)-1-tot] , dic )# i think i put this in the right place 
			#print("we are")
			#print(nethold[x])
			nethold[x]=vector_mult(nethold[x],holder, rows[len(net)-1-tot] ,dic)
			
			#print()
			#print(holder)
			#print()
			#print(nethold[x])
			#print("here")
		#print(lear_rate[tot])
		print(lear_rate[tot])
		pet[len(net)-1-tot]=matrixadd( pet[len(net)-1-tot], matrix_mult_by_consent(   nethold, lear_rate[tot] , rows[len(net)-1-tot] , mfd )   , rows[len(net)-1-tot] ,   dic  )
	#print(len(pet[0][0][0]))
	#print("end")
	return pet


# old back
#/def back_ward_prop(net,output,net_type,nerds,lear_rate, dic,rows):
	#/pet=numpy_net(net,net_type)

	#/nerons=[0]*len(net_type)
	
	#/for x in range(len(net_type)):
	#/	nerons[x]=zeros_F(net_type[x]+1)
	#/	nerons[x][net_type[x]]=[1]
	

	#/for x in range(len(output)):
	#/	nerons[ len(nerons)-1 ][x]=output[x]

	#/for tot in range(len(net_type)-1):
	#/	val1=sig_vec( nerons[ len(nerons)-1-tot] ,5 ,dic )
	#/	val2=sig_vec(nerds[len(nerons)-1-tot] , 5 , dic)
	#/	delta=subtractvec(val1 ,val2 , 5 , dic)
	#/	delta.pop(len(delta)-1)

	#/	holder=sig_vec(nerds[len(nerons)-2-tot] , 5 , dic)

		
	#/	nethold=copy.deepcopy(pet[len(net)-1-tot])

	#/	for x in range(len(nethold)):
			#print("we are")
			#print(delta[tot][x])
			#print(nethold[x])
			#print("here")
	#/		nethold[x]=vector_mult_by_consent(nethold[x], delta[x] , 5 , dic )# i think i put this in the right place 
			#print("we are")
			#print(nethold[x])
	#/		nethold[x]=vector_mult(nethold[x],holder, 5 ,dic)
			
			#print()
			#print(holder)
			#print()
			#print(nethold[x])
			#print("here")

	#/	pet[len(net)-1-tot]=matrixadd( pet[len(net)-1-tot], matrix_mult_by_consent(   nethold, lear_rate[tot] , 5 , mfd )   , 5 ,   dic  )

	#/return pet

def zeros_F(val):
	out=[0]*val
	for x in range(val):
		out[x]=[0]
	return out

def zeros_Fnp(val):

	return np.zeros(val)
#loc="/Users/ahauss/Desktop/net1/"

#mutlt_func(func1,func2,rank,inmat=None):
def matrixadd(matix1,matix2,rank,dic):
	out=[0]*len(matix1)
	for y in range(len(matix1)):
		out[y]=[0]*len(matix1[0])
	for x in range(len(matix1)):
		for y in range(len(matix2[0])):
			#the matrix add
			out[x][y]=poly.add_func_map( matix2[x][y], matix1[x][y], rank, dic)
	return out


# sub_func_map(func1,func2,rank,dic):
def subtractvec(vec1,vec2,rank,dic):
	out=[0]*len(vec1)
	for x in range(len(vec1)):
		#the sub
		out[x]= poly.sub_func_map( vec1[x] , vec2[x] , rank , dic)
	return out


def vecmult(vec,number):
	#print(vec)
	#quit()
	out=np.arange(len(vec))
	#print(vec)
	#print(number)
	for x in range(len(vec)):
		#print(vec[x])

		out[x]=float(vec[x])*number[0]
	return out
def matrix_mult_by_consent(matix,conset,rank,dic):

	out=[0]*len(matix)
	for y in range(len(matix)):
		out[y]=[0]*len(matix[0])
	for x in range(len(matix)):
		for y in range(len(matix[0])):


			out[x][y]=vecmult( matix[x][y] , conset)
			#print("x,ything out",out[x][y])
	return out


def vector_mult(vec1,vec2,rank,dic):
	out=[0]*len(vec1)
	for x in range(len(vec1)):
		#the mult 
		out[x]=poly.mult_func_map( vec1[x] , vec2[x] ,  rank , dic )
	return out


def zeros_f_F(one,two):
	out=[0]*one
	for x in range(one):
		out[x]=[0]*two
		for y in range(two):
			out[x][y]=[0]
	return out


def vector_mult_by_consent(vec1,conset,rank,dic):
	out=[0]*len(vec1)
	for x in range(len(vec1)):
		#the mult
		out[x]=poly.mult_func_map( vec1[x] , conset ,  rank , dic )
	return out


def numpydot(net,nerons):
	print("we are in")
	return np.dot(net,nerons)



def mydot(a,b,rank,dic):
	

	out=[0]*len(a)
	for x in range( len(a) ):
		out[x]=[0]

	for x in range(len(a)):
		for y in range(len(b)):
			#the mult
			#print("a",a[x][y] )
			#print("b",b[y] )
			#print("we here")
			#print(a[x][y],b[y])
			#print(a[x][y])
			#quit()
			adder=poly.mult_func_map( a[x][y] , b[y] ,  rank , dic ) 
			#print("next")
			#print(out[x])
			out[x]= poly.add_func_map(  out[x] ,adder , rank , dic)
			#print("were out")
			#print(adder)
			#print(out[x])
	return out




