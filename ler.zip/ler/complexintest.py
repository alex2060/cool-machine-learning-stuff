inport numpy as 



