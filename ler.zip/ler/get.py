import numpy as np
import matplotlib.pyplot as plt
import math
from numpy import arange
import pylab
vector1=[1,2,-1,2,4,1,2,4,2,4,1,-2,1,3,-2,10]
start_time=-math.pi
endds_time=math.pi
def set_plot_F(vector1,start_time,endds_time):
	vec1=[""]*(len(vector1)*2+1)
	vec1[0]=vector1[0]
	vecs1=[""]*(len(vector1)*2)
	for x in range(len(vector1)):
		vecs1[2*x+0]=vector1[x]
		vecs1[2*x+1]=vector1[x]
	time1=[""]*len(vecs1)
	time1[0]=start_time
	#print(len(time1))
	#print(endds_time-start_time)
	for x in range(len(time1)//2-1):
		time1[2*x+0+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
		time1[2*x+1+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
			
	time1[len(time1)-1]=endds_time
	#vector1[len(vector1)-1]=vector1[len(vector1)-1]*2

	pylab.plot(time1,vecs1)
	plt.show()
foir_F(vector1,start_time,endds_time)

