
# multitivariable regertion
import numpy as np

vector=[""]*4
vector[0]=[1,2,3]
vector[1]=[1,2,8]
vector[2]=[2,2,3]
vector[3]=[1,4,2]


v=[""]*len(vector)
for z in range(1):
	v=[0]*len(vector[0])
	for x in range(len(vector[0])):
		v[x]=np.arange(len(vector[0]))
		for y in range(len(vector[0])):
			v[x][y]=vector[z][x]


print(v[0])
print(v[1])
print(v[2])






