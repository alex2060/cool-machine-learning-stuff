import numpy as np
import matplotlib.pyplot as plt
import math
from numpy import arange
import pylab
vector1=[1,2,-1,2,4,1,2,4,2,4,1,-2,1,3,-2,10]
start_time=0
endds_time=math.pi
number=len(vector1)
def foir_F(vector1,start_time,endds_time,number):
	vec1=[""]*(len(vector1)*2+1)
	vec1[0]=vector1[0]
	for x in range(len(vector1)-1):
		vec1[2*x+1]=vector1[x+1]
		vec1[2*x+2]=vector1[x+1]
	vecs1=[""]*(len(vector1)*2)
	for x in range(len(vector1)):
		vecs1[2*x+0]=vector1[x]
		vecs1[2*x+1]=vector1[x]
	time1=[""]*len(vecs1)
	time1[0]=start_time
	for x in range(len(time1)//2-1):
		time1[2*x+0+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
		time1[2*x+1+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
	time1[len(time1)-1]=endds_time
	def de_in_sin_F(a,top,bot):
		return (math.cos(a*bot)-math.cos(a*top))/a
	def de_in_cos_F(a,top,bot):
		return (math.sin(a*top)-math.sin(a*bot))/a
	S=[0]*number
	C=[0]*number
	for x in range(number):
		a=2*math.pi*(x+1)/(endds_time-start_time)
		for y in range(len(time1)//2):
			
			mult=de_in_sin_F(a,time1[2*y],time1[2*y+1])
			add=vector1[y]*mult
			S[x]=S[x]+add
			mult2=de_in_cos_F(a,time1[2*y],time1[2*y+1])
			add2=vector1[y]*mult2
			C[x]=C[x]-add2
		S[x]=2*S[x]/(start_time-endds_time)
		C[x]=2*C[x]/(endds_time-start_time)
	#print(S[0])
	A0=0
	#vector1[len(vector1)-1]=vector1[len(vector1)-1]*2

	A0=(sum(vector1))/(len(vector1))
	return [[endds_time,start_time],A0,S,C]

def foir_real_F(vector1,start_time,endds_time,number):
	vec1=[""]*(len(vector1)*2+1)
	vec1[0]=vector1[0]
	for x in range(len(vector1)-1):
		vec1[2*x+1]=vector1[x+1]
		vec1[2*x+2]=vector1[x+1]
	vecs1=[""]*(len(vector1)*2)
	for x in range(len(vector1)):
		vecs1[2*x+0]=vector1[x]
		vecs1[2*x+1]=vector1[x]
	time1=[""]*len(vecs1)
	time1[0]=start_time
	for x in range(len(time1)//2-1):
		time1[2*x+0+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
		time1[2*x+1+1]=start_time+2*(endds_time-start_time)*(x+1)/(len(time1))
	time1[len(time1)-1]=endds_time
	def de_in_sin_F(a,top,bot):
		return (math.cos(a*bot)-math.cos(a*top))/a
	def de_in_cos_F(a,top,bot):
		return (math.sin(a*top)-math.sin(a*bot))/a
	S=[0]*number
	C=[0]*number
	for x in range(number):
		a=2*math.pi*(x+1)/(endds_time-start_time)
		for y in range(len(time1)//2):
			
			mult=de_in_sin_F(a,time1[2*y],time1[2*y+1])
			add=vector1[y]*mult
			S[x]=S[x]+add
			mult2=de_in_cos_F(a,time1[2*y],time1[2*y+1])
			add2=vector1[y]*mult2
			C[x]=C[x]-add2
		S[x]=2*S[x]/(start_time-endds_time)
	#print(S[0])
	A0=0
	#vector1[len(vector1)-1]=vector1[len(vector1)-1]*2

	A0=(sum(vector1))/(len(vector1))
	return [[endds_time,start_time],A0,S]
def fori_plot_F(vector):#[endtime,starttime],constent,[sins],[cos]
	t = np.linspace(vector[0][1],vector[0][0],1000)
	p=vector[1]
	for x in range(number):
		print(2*math.pi*(x+1)/(start_time-endds_time))
		p=p+vector[2][x]*np.sin(2*math.pi*(x+1)*t/(vector[0][0]-vector[0][1]))+vector[3][x]*np.cos(2*math.pi*(x+1)*t/(vector[0][0]-vector[0][1]))
	
	pylab.plot(t,p)
	plt.show()

def fori_real_plot_F(vector):#[endtime,starttime],constent,[sins],[cos]
	t = np.linspace(vector[0][1],vector[0][0],1000)
	p=vector[1]
	for x in range(number):
		print(2*math.pi*(x+1)/(start_time-endds_time))
		p=p+vector[2][x]*np.sin(2*math.pi*(x+1)*t/(vector[0][0]-vector[0][1]))
	
	pylab.plot(t,p)
	plt.show()

kp=foir_real_F(vector1,start_time,endds_time,number)
print(kp[0])
fori_real_plot_F(kp)




