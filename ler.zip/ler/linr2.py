import numpy as np
from numpy.linalg import inv
vector=[""]*3
vector[0]=[1,2,3]
vector[1]=[1,2,8]
vector[2]=[2,2,3]

result=[1,2,4]
matrix=np.zeros(shape=(len(vector[0]),len(vector[0])))

def addrix(vector):
	addrix=np.zeros(shape=(len(vector),len(vector)))
	for x in range(len(vector)):
		v=[vector[x]]*len(vector)
		addrix[x]=v
	return addrix
def multrix(vector):
	multrix=np.zeros(shape=(len(vector),len(vector)))
	for x in range(len(vector)):
		v=[0]*len(vector)
		for y in range(len(vector)):
			if y==x:
				v[y]=vector[x]
		multrix[x]=v
	return multrix
def addermatrix(vector):
	return np.dot(addrix(vector),multrix(vector))
def advec(vec1,mult1,vec2,mult2):
	rec=[0]*len(vec1)
	for x in range(len(vec1)):
		rec[x]=vec1[x]*mult1+vec2[x]*mult2
	return rec
def mat_to_be_inversed_F(vec):
	addermat=np.zeros(shape=(len(vec[0]),len(vec[0])))
	for x in range(len(vec)):
		addermat=addermat+addermatrix(vec[x])
	return addermat
def makevec_F(vec,res):
	ret=[0]*len(vec[0])
	for x in range(len(ret)):
		ret=advec(ret,1,vec[x],res[x])
	return ret
def lin_r(vector,result):
	mat=mat_to_be_inversed_F(vector)
	vects=makevec_F(vector,result)
	return np.dot(inv(mat),vects)
res=lin_r(vector,result)
test=np.dot(res,vector[2])
print(test)

