import numpy as np
from numpy.linalg import inv

v=[""]*3
v[0] = np.array([1+2j, 3+4j, 5+6j])
v[1] = np.array([3+8j, 4+2j, 2+2j])
v[2] = np.array([3+8j, 4+2j, 2+2j])
matrixt=np.zeros(shape=(3,3))
matrixt[0]=np.array([1+2j, 3+4j, 5+6j])
matrixt[1]=np.array([3+8j, 4+2j, 2+2j])
matrixt[2]=np.array([3j, 4+2j, 2+2j])
k=np.linalg.det(matrixt)

print(matrixt[1])
print(matrixt[1]*(3+1j))
input()


#http://www.wolframalpha.com/input/?i=%7B%7B1%2Bi,3%2B4i,5%2B6i%7D,%7B3%2B8i,4%2B2i,2%2B2i%7D,%7B0%2B3i,4%2B2i,2%2B2i%7D%7D