import numpy as np
import copy
from numpy.linalg import inv
print("eheress2")
import matplotlib.pyplot as plt



def differance(fun1,fun2,rank,dic):
	if rank==1:
		return 1;
	sutm=0
	for x in range( rank ):
		sutm+=abs( outfunc(fun1, (x/(rank-1)) ) -outfunc(fun2, (x/(rank-1)) ) )
	return  sutm
		

def data_to_function(data,rank):
	# where the fast hankle solver goes 
	if rank==1:
		return [sum(data)/len(data)]
	matrix=np.zeros((rank, rank))
	vec=np.zeros(rank)
	for z in range(len(data)):
		for x in range(rank):
			for y in range(rank):
				matrix[x][y]+=( z/(len(data)-1) )**(x+y)
	for z in range( len(data) ):
		for x in range( rank ):
			vec[x]+=data[z]*( z/(len(data)-1) )**(x)
	inmatrix=inv(matrix)
	out=np.dot(inmatrix,vec)
	return out




def make_matrix_inv(rank,number):
	matrix=np.zeros((rank, rank))
	vec=np.zeros(rank)
	#print(number)
	for z in range(number):
		#print(z)
		for x in range(rank):
			for y in range(rank):
				matrix[x][y]+=( z/(number-1) )**(x+y)
	return inv(matrix)


def data_to_function_with_inv_matrix(data,rank,inmatrix):
	#print("here")
	#print("this bit",data)
	if rank==1:
		return [sum(data)/len(data)]
	vec=np.zeros(rank)
	for z in range( len(data) ):
		for x in range( rank ):
			vec[x]+=data[z]*( z/(len(data)-1) )**(x)
	out=np.dot(inmatrix,vec)
	return out

def data_to_function_with_dic(data,rank,dic):
	if rank==1:
		return [sum(data)/len(data)]
	vec=np.zeros(rank)
	for z in range( len(data) ):
		#print(z)
		for x in range( rank ):
			vec[x]+=data[z]*( z/(len(data)-1) )**(x)
	key="rank"+str(rank)+"_values"+str(len(data))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=make_matrix_inv(rank,len(data))
		dic[key] = inmatrix
		print("made key")
	out=np.dot(inmatrix,vec)
	return out

def outfunc(data,number):
	sut=0
	for x in range(len(data)):
		sut+=data[x]*number**x
	return sut

def mutlt_func(func1,func2,rank,inmat=None):
	if rank==1:
		return [func1[0]*func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes 
		out[x]= outfunc(func1, (x/(rank-1)) ) *  outfunc(func2, (x/(rank-1)) ) 
	if inmat is not None:
		return data_to_function_with_inv_matrix(out,rank,inmat)
	return data_to_function(out,rank)

def add_func(func1,func2,rank,inmat=None):
	if rank==1:
		return [func1[0]+func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) + outfunc(func2, (x/(rank-1)) ) 
	if inmat is not None:

		return data_to_function_with_inv_matrix(out,rank,inmat)
	return data_to_function(out,rank)

def sub_func(func1,func2,rank,inmat=None):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) -  outfunc(func2, (x/(rank-1)) ) 
	if inmat is not None:
		return data_to_function_with_inv_matrix(out,rank,inmat)
	return data_to_function(out,rank)

def sub_func_map(func1,func2,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) -  outfunc(func2, (x/(rank-1)) ) 
	key="rank"+str(rank)+"_values"+str(len(out))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=make_matrix_inv(rank,len(out))
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)



def mult_func_map(func1,func2,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) *  outfunc(func2, (x/(rank-1)) ) 
	key="rank"+str(rank)+"_values"+str(len(out))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=make_matrix_inv(rank,len(out))
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)

def dev_func_map(func1,func2,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) /  outfunc(func2, (x/(rank-1)) ) 
	key="rank"+str(rank)+"_values"+str(len(out))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=make_matrix_inv(rank,len(out))
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)

def add_func_map(func1,func2,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) +  outfunc(func2, (x/(rank-1)) ) 
	key="rank"+str(rank)+"_values"+str(len(out))
	#print("the _values are",out)
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=make_matrix_inv(rank,len(out))
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)


def sig(x):# sigmod function 
	return 1/(1+np.exp(-x))

def sig_func_map(func1,rank,dic):
	if rank==1:
		return [func1[0]-func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= sig( outfunc(func1, (x/(rank-1)) ) )

	key="rank"+str(rank)+"_values"+str(len(out))
	#print(key)
	if key in dic:
		inmatrix=dic[key]
		#print("used key")
	else:
		inmatrix=make_matrix_inv(rank,len(out))
		dic[key] = inmatrix
		#print("made key")
	return data_to_function_with_inv_matrix(out,rank,inmatrix)



def dev_func(func1,func2,rank,inmat=None):
	if rank==1:
		return [func1[0]/func2[0]]
	out=[0]*rank
	for x in range(rank):
		# where fast manipule multiplaication goes
		out[x]= outfunc(func1, (x/(rank-1)) ) /  outfunc(func2, (x/(rank-1)) ) 
	if inmat is not None:
		return data_to_function_with_inv_matrix(out,rank,inmat)
	return data_to_function(out,rank)

#out=[0]*10
#for x in range(10):
#	out[x]=x

#inv10_10=make_matrix_inv(10,10)

#thedat=[1,2,3,4,5,6]
#rank=4
#data_to_function_with_dic(thedat,rank,thisdict)
#k=data_to_function_with_dic(thedat,rank,thisdict)
#rout=sub_func_map(k,k,rank,thisdict)
#rout=sub_func_map(k,k,rank,thisdict)
#rout=mult_func_map(k,k,rank,thisdict)
#rout=dev_func_map(k,k,rank,thisdict)
#rout=add_func_map(k,k,rank,thisdict)

