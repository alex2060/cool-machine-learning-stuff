import newfist_try_F as nets
import numpy as np
import random
import copy
import newpoly as poly
print("we are a go and we go")
loc="/Users/ahauss/Desktop/net_2mine/"
def get_matrix_numbs(loc,name):
	with open(loc+name+".txt","r") as f:
		array=[""]
		for line in f:
			m=line
			m=m.strip("\n")
			m=m.split(",")
			for x in range(len(m)):
				m[x]=float(m[x])
			array.append(m)
	f.close()
	array.pop(0)
	return array

def make_say_depth(net,row):
	for x in range(len(net)):
		if ( len(net[x][0][0])!=row[x]):
			if ( len(net[x][0][0])>row[x]):
				for y in range(len(net[x])):
					#print(net[x][y])
					for k in range(len(net[x][y])):
						for z in range(len(net[x][0][0])-row[x]):
							net[x][y][k].pop(len(net[x][y][k])-1)
							print(x,y,z,"we go")
			if ( len(net[x][0][0])<row[x]):
				for y in range(len(net[x][0])):
					for k in range(len(net[x][y])):
						for z in range(row[x]-len(net[x][0][0])):
							net[x][y][k].append( (random.random()-0.5)/10 )
							print(x,y,z,"we are a go")
	return net



row=[15,9,4,4,5]
net_type=[1,7,15,10,1]


loc="/Users/alex/Desktop/mypower_incrate/2p/try1p/"
randnet=nets.make_random_net_with_bies(net_type,row)
nets.store_net(loc,randnet)

newnet=nets.get_net(loc,net_type)
print("len at very start")
print(len(newnet[0][0][0]))

getloc="/Users/alex/Desktop/mypower_incrate/adio/"

zeroadio=get_matrix_numbs(getloc,"0")
zeroadio=zeroadio[0]
max1=max(zeroadio)
min1=min(zeroadio)
zeroadio=zeroadio[2000:2050]
oneadio=get_matrix_numbs(getloc,"1")
oneadio=oneadio[0]
max2=max(oneadio)
min2=min(oneadio)
oneadio=oneadio[2000:2050]
598910400.0-693829632.0
#print(oneadio)
#print(zeroadio)




for x in range(len(oneadio)):
	pass
	#oneadio[x]=(oneadio[x]+693829632.0)/(598910400.0+693829632.0)
	#zeroadio[x]=(zeroadio[x]+693829632.0)/(598910400.0+693829632.0)






getloc="/Users/alex/Desktop/mypower_incrate"
oneimg=[0]*900
zerimg=[0]*900

imp=[0]*1800
start=[0]*1800
for x in range(900):
	oneimg[x]=get_matrix_numbs(getloc,"/1/0_"+str(x+1)+"")
	zerimg[x]=get_matrix_numbs(getloc,"/0/0_"+str(x+1)+"")
	imp[2*x+0]=[[1,1,1,1,1,1,1,1]]
	start[2*x+0]=[oneimg[x][0]]

	imp[2*x+1]=[[0,2,4,2,1,0,0]]
	start[2*x+1]=[zerimg[x][0]]







mfd = {}





lear_rate=[[0.002],[0.002],[0.002],[0.002],[0.002],[0.002]]
neglear_rate=[[-0.00000000001],[0.00000000001],[0.00000000001],[0.000000001],[0.002]]

numberofloops=10


#print("len at startnew")
#print(newnet[0][0])
#print(start[0])
#print(len(start))
newonw=np.arange(len(start[0][0]))
for k in range(len(start[0][0])):
	#print(start[0][0][k])
	newonw[k]=start[0][0][k]
#print("next")
#print(len(start[0][0]))
#print(newonw)
out1=poly.data_to_function_with_dic(newonw,row[0],mfd)

out=nets.for_ward_prop2(newnet,[out1],net_type,mfd,row)
#print("webig")
#print(newnet[0][0])
#print("wedone")
#nets.store_net(loc,newnet)


#fun1=[0.9,3,5,2,5,6,2]
#fun2=[4,2,1,1,2,3,4]
#out1=poly.return_Function_C_S(fun1,1,0,number)
#out2=poly.return_Function_C_S(fun2,1,0,number)

oldtot=300000000000000
numberof=10
#print(newonw)
for x in range(2):


	total=0
	theoldnet=copy.deepcopy(newnet)

	for y in range(numberof):
		print("y",y," x",x)

		for z in range(10):
			print("z",z)
			newnet=nets.back_ward_prop(newnet,imp[y],net_type,out,lear_rate,mfd,row)

			for k in range(len(start[y])):
				#print(start[y][k])
				newonw[k]=start[y][0][k]
			out1=poly.data_to_function_with_dic(newonw,row[0],mfd) 
				
			out=nets.for_ward_prop2(newnet,[out1],net_type,mfd,row)
		#print("her")
		here=poly.differance(out[len(out)-1][0],imp[y][0],len(imp[y][0]),mfd)
		print(out[len(out)-1][0],imp[y][0])
		print("thediferance")
	print("the total")
	print(total/numberof)



print("the imp len")
input()
nets.store_net(loc,newnet)
print("we saved the net")
#5.002742135796178