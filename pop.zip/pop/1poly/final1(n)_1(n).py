
import numpy as np
from numpy.linalg import inv

def multpoly_full(a,b):
	out=[0]*(len(a)+len(b))
	for x in range(len(a)):
		for y in range(len(b)):
			out[x+y]=a[x]*b[x]
	return out

def list_subtract(list1,list2,C):
	out=[0]*len(list1)
	for x in range(len(list1)):
		out[x]=list1[x]-list2[x]*c
	return out


def defintet_intigral(poly):
	out=0
	for x in range(len(poly)):
		out+=poly/(x+1)
	return out



a=[1,2]
b=[3,4]
aw=[5,6,7]


print(multpoly_full(a,b))
