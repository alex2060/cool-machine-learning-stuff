import newfist_try_F1 as nets
import numpy as np
import random
import copy
import newpoly1number2 as poly
import math
print("we are a go and we go")
loc="/Users/ahauss/Desktop/net_2mine/"
def get_matrix_numbs(loc,name):
	with open(loc+name+".txt","r") as f:
		array=[""]
		for line in f:
			m=line
			m=m.strip("\n")
			m=m.split(",")
			for x in range(len(m)):
				m[x]=float(m[x])
			array.append(m)
	f.close()
	array.pop(0)
	return array

def make_say_depth(net,row):
	for x in range(len(net)):
		if ( len(net[x][0][0])!=row[x]):
			if ( len(net[x][0][0])>row[x]):
				for y in range(len(net[x])):
					#print(net[x][y])
					for k in range(len(net[x][y])):
						for z in range(len(net[x][0][0])-row[x]):
							net[x][y][k].pop(len(net[x][y][k])-1)
							print(x,y,z,"we go")
			if ( len(net[x][0][0])<row[x]):
				for y in range(len(net[x][0])):
					for k in range(len(net[x][y])):
						for z in range(row[x]-len(net[x][0][0])):
							net[x][y][k].append( (random.random()-0.5)/10 )
							print(x,y,z,"we are a go")
	return net


#poly.returnval([0,0,1],1.21)
row=[5,7,11]
net_type=[50,10,1]


loc="/Users/alex/Desktop/mypower_incrate/2p/try1p/"
randnet=nets.make_random_net_with_bies(net_type,row)
nets.store_net(loc,randnet)

newnet=nets.get_net(loc,net_type)
print("len at very start")
print(len(newnet[0][0][0]))

getloc="/Users/alex/Desktop/mypower_incrate/adio/"

zeroadio=get_matrix_numbs(getloc,"0")
zeroadio=zeroadio[0]
max1=max(zeroadio)
min1=min(zeroadio)
zeroadio=[0.5,0,0.1]
oneadio=get_matrix_numbs(getloc,"1")
oneadio=oneadio[0]
max2=max(oneadio)
min2=min(oneadio)
oneadio=[0.5,0,-0.1]

#print(oneadio)
#print(zeroadio)




for x in range(len(oneadio)):
	pass
	#oneadio[x]=(oneadio[x]+693829632.0)/(598910400.0+693829632.0)
	#zeroadio[x]=(zeroadio[x]+693829632.0)/(598910400.0+693829632.0)






getloc="/Users/alex/Desktop/mypower_incrate"
oneimg=[0]*900
zerimg=[0]*900

imp=[0]*1800
start=[0]*1800
for x in range(900):
	oneimg[x]=get_matrix_numbs(getloc,"/1/0_"+str(x+1)+"")
	zerimg[x]=get_matrix_numbs(getloc,"/0/0_"+str(x+1)+"")
	imp[2*x+0]=[oneadio]
	start[2*x+0]=[oneimg[x][0]]

	imp[2*x+1]=[zeroadio]
	start[2*x+1]=[zerimg[x][0]]







mfd = {}


def make_begining(data,number,row):
	theout=[0]*number
	#print("number ",len(data))
	newonw=np.arange(len(data))
	for x in range(len(data)):
		newonw[x]=data[x]
	out1=poly.return_Function_C_S(newonw,0,1,row)
	for y in range(number):
		theout[y]=poly.shift_function(out1,len(data),row, y/math.pi)
	return theout


def vecmult(vec,number):
	out=[0]*len(vec)
	for x in range(len(vec)):

		out[x]=[vec[x][0]*number]
	return out
lear_rate=[[0.014],[0.014],[0.014],[0.014],[1]]
neglear_rate=[[-0.00000000001],[0.00000000001],[0.00000000001],[0.000000001],[0.002]]

numberofloops=50


#print("len at startnew")
#print(newnet[0][0])

print(start[0])

print("50")
print("next")
print("50_26")

theway=make_begining(start[0][0],net_type[0],row[0])


out=nets.for_ward_prop2(newnet,theway,net_type,mfd,row)
#print("webig")
#print(newnet[0][0])
#print("wedone")
#nets.store_net(loc,newnet)


#fun1=[0.9,3,5,2,5,6,2]
#fun2=[4,2,1,1,2,3,4]
#out1=poly.return_Function_C_S(fun1,1,0,number)
#out2=poly.return_Function_C_S(fun2,1,0,number)


numberof=1
print("final number")
print(numberof)
for x in range(1):


	total=0
	theoldnet=copy.deepcopy(newnet)

	for y in range(numberof):
		print("y",y," x",x)

		theway=make_begining(start[y][0],net_type[0],row[0])


		for z in range(10):
			print("z",z)
			
			out=nets.for_ward_prop2(newnet,theway,net_type,mfd,row)
			mult=poly.differance(out[len(out)-1][0],imp[y][0],100,mfd)
			print(mult)
			newnet=nets.back_ward_prop(newnet,imp[y],net_type,out,vecmult(lear_rate,5),mfd,row)


		#print("her")
		here=poly.differance(out[len(out)-1][0],imp[y][0],100,mfd)
		print("here",here)

		total=total+here
	print(x)
	print(((total/100)/(numberof)))
	newtot=0
	
	print("the test")
	numberoftests=2
	sumoftests=0
	for x in range(numberoftests):
		print("x",x)
		
		theway=make_begining(start[x][0],net_type[0],row[0])
		out=nets.for_ward_prop2(newnet,theway,net_type,mfd,row)
		


		newout=nets.for_ward_prop2(newnet,theway,net_type,mfd,row)
		actual=poly.differance(out[len(out)-1][0],imp[x][0],100,mfd)
		sumoftests+=actual
		one=poly.differance(out[len(out)-1][0],[0.5,0,0.1],100,mfd)
		zero=poly.differance(out[len(out)-1][0],[0.5,0,-0.1],100,mfd)
		print("1 ",one," 0",zero)
		if imp[x][0]==[0.5,0,0.1]:
			if one<zero:
				print("true")
			else:
				print("flase")
		else:
			if zero>one:
				print("true")
			else:
				print("flase")
	print("reuts of test",(sumoftests/(100*numberoftests)))
		#print((actual/100))
		#print(imp[x][0])
		#print("the function",out[len(out)-1][0])
		#poly.plotfunction(out[len(out)-1][0],1000)


		#if imp[x][0]==[0.5,0,0.2]:

		#	if check<actual:
		#		print("true,0")
		#	else:
		#		print("flase,0")
		#if imp[x][0]==[0.5,0,0.1]:
		#	check=poly.differance(out[len(out)-1][0],[0.5,0,0.1],100,mfd)
		#	actual=poly.differance(out[len(out)-1][0],[0.5,0,0.2],100,mfd)
		#	print("1 ",check," 0 ",actual)
		#	if check<actual:
		#		print("true,1")
		#	else:
		#		print("flase,1")
		
		#newtot+=actual
	print("we are done",newtot/(100*numberof))


for x in range(2):
	theway=make_begining(start[x][0],net_type[0],row[0])
	nets.for_ward_prop2(newnet,theway,net_type,mfd,row)
	print(out[len(out)-1][0])
	poly.plotfunction(out[len(out)-1][0],1000)


print("the imp len")
input()
nets.store_net(loc,newnet)
print("we saved the net")
#5.002742135796178
